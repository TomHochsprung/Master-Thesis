chow_liu <- function(l,
                     n,
                     cov_matrix = NULL,
                     type = "normal") {
  t1 <- Sys.time()
  if (approach != 1) {
    query_type_local <- get("query_type", 1)
  }
  if (type == "normal") {
      if (is.null(cov_matrix)) {
        cov_matrix <- matrix(numeric(l * l), ncol = l, nrow = l)
        for (i in 1:l) {
          for(j in 1:i) {
            cov <- calculate_cov(n, i, j, type = query_type)
            cov_matrix[i, j] <- cov
            cov_matrix[j, i] <- cov 
          }
        }
  }
  corr <- cov2cor(cov_matrix)
  weights <- abs(corr)
  } else {
    weights <- get("all_mutual_infos", 1)
  }
  adj_matrix <- kruskal2(weights)
  t2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t2, t1, units = "secs")
  return(list("adj_matrix" = adj_matrix,
              "t_diff" = t_diff))
}
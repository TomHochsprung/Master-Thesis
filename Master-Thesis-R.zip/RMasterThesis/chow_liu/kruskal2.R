kruskal2 <- function(weights) {
  A <- numeric(0)
  non_zero_weights <- weights[lower.tri(weights)]
  sorted_weights <- sort(non_zero_weights, decreasing = TRUE)
  d <- dim(weights)
  counter_edges <- 0
  adj_matrix_old <- matrix(numeric(prod(d)), nrow = d[1])
  parents <- 1:d[1]
  rks <- numeric(d[1])
  for (w in sorted_weights) {
    pos <- which(weights == w, arr.ind = TRUE)
    u <- pos[1, 1]
    v <- pos[1, 2]
    if (find_set(u, parents) != find_set(v, parents)) {
    adj_matrix_old[pos[1, 1], pos[1, 2]] <- 1
    adj_matrix_old[pos[1, 2], pos[1, 1]] <- 1
    res <- union(u, v, parents, rks)
    parents <- res$parents
    rks <- res$rks
    }
  }
  return(adj_matrix_old)
}


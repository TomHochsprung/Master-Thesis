dfs <- function(adj_matrix, root_node, colours, predecessors){
  cycle_found <- FALSE
  nbs <- which(adj_matrix[root_node, ] == 1)
  colours[root_node] <- "Grey"
  for(nb in nbs){
    if(colours[nb] == "White"){
      predecessors[nb] <- root_node
      result <- dfs(adj_matrix, nb, colours, predecessors)
      colours <- result$colours
      predecessors <- result$predecessors
      cycle_found <- cycle_found | result$cycle_found
    }
    if((colours[nb] == "Grey") & (nb != predecessors[root_node])){
      cycle_found <- TRUE
    }
    if(cycle_found == TRUE){
      break
    }
  }
  colours[root_node] <- "Black"
  return(list("colours" = colours,
              "predecessors" = predecessors,
              "cycle_found" = cycle_found))
}

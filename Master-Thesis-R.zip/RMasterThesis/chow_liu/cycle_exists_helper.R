cycle_exists_helper <- function(current_node, last_node, adj_matrix, visited) {
  nbs <- which(adj_matrix[current_node, ] == 1)
  new_nbs <- setdiff(nbs, last_node)
  if (length(new_nbs) != 0) {
    if(length(intersect(new_nbs, setdiff(visited, last_node))) != 0){
      return(TRUE)
    } else {
      bool <- FALSE
      for(n in new_nbs){
        visited <- c(visited, current_node)
        bool <-  cycle_exists_helper(current_node = n,
                                     last_node = current_node,
                                     adj_matrix, visited)
        if(bool == 1){
          break
        }
      }
      return(bool)
    } 
    } else {
      return(FALSE)
    }
}


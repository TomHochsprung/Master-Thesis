find_set <- function(x, parents) {
  if(x != parents[x]){
    parents[x] <- find_set(parents[x], parents)
  }
  return(parents[x])
}
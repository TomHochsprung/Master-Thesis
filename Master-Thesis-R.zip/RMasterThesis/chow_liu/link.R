link <- function(x, y, parents, rks) {
  if(rks[x] > rks[y]) {
    parents[y] <- x
  } else {
      parents[x] <- y
      if(rks[x] == rks[y]){
        rks[y] == rks[y] + 1
      }
  }
  list("parents" = parents, "rks" = rks)
}
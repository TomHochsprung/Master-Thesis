paste_chow_liu <- function(adj_matrix) {
  edges <- character(0)
  for (i in 1:dim(adj_matrix)[1]) {
    for (j in 1:i) {
      if (adj_matrix[j,i]==1) {
        edges <- c(edges, paste0(j, "-", i))
      }
  }
  }
  return(edges)
}
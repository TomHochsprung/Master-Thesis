calculate_all_mutual_infos <- function(l, n) {
  mutual_info_matrix <- matrix(numeric(l * l), ncol = l)
  for(i in 2:l){
    for(j in 1:(i - 1)) {
      new_mutual_info <-  calculate_mutual_info(j, i, n)
      mutual_info_matrix[i, j] <- new_mutual_info
      mutual_info_matrix[j, i] <- new_mutual_info
    }
  }
  return(mutual_info_matrix)
}

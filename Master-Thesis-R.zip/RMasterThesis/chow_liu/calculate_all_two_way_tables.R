calculate_all_two_way_tables <- function(l) {
  tables_list <- list()
  for(i in 2:l){
    for(j in 1:(i - 1)) {
        new_table <-  calculate_two_way_table(j, i)
        tables_list[[length(tables_list) + 1]] <- new_table
        names(tables_list)[length(tables_list)] <- paste(j, "-", i)
    }
  }
  return(tables_list)
}

check_cycle <- function(adj_matrix, root_node) {
  cycle_exists <- cycle_exists_helper(root_node,
                                      root_node,
                                      adj_matrix,
                                      root_node)
  return(sum(cycle_exists)>0)
}


union <- function(x, y, parents, rks) {
  f1 <- find_set(x, parents)
  f2 <- find_set(y, parents)
  return(link(f1, f2, parents, rks))
}
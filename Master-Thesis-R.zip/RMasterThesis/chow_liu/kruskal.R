# old implementation, works, but is slower than kruskal2
kruskal <- function(weights) {
  non_zero_weights <- weights[lower.tri(weights)]
  sorted_weights <- sort(non_zero_weights, decreasing = TRUE)
  d <- dim(weights)
  counter_edges <- 0
  adj_matrix_old <- matrix(numeric(prod(d)), nrow = d[1])
  for (w in sorted_weights){
    pos <- which(weights == w, arr.ind = TRUE)
    adj_matrix_new <- adj_matrix_old
    adj_matrix_new[pos[1, 1], pos[1, 2]] <- 1
    # issues with computer arithmetic, so we need to do it for the "symmetric"
    # entry as well
    adj_matrix_new[pos[1, 2], pos[1, 1]] <- 1 
    cycle_created <- dfs(adj_matrix_new, root_node = pos[1],
                         rep("White", d[1]),
                         character(d[1]))$cycle_found
    if (cycle_created == FALSE) {
      adj_matrix_old <- adj_matrix_new
      counter_edges <- counter_edges + 1
    }
    if (counter_edges == d[1] - 1) {
      break
    }
  }
  return(adj_matrix_old)
}

calculate_two_way_table <- function(x, y) {
  dat <- fread(input = "simulations/data_storage/data.csv",
               skip = 1,
               select = unique(c(x, y)),
               data.table = FALSE)
  two_way_table <- array(0, c(2, 2))
  for(i in 1:2){
    for(j in 1:2){
        two_way_table[i, j] <-
          nrow(dat[(dat[, 1] == (i - 1)) & (dat[, 2] == (j - 1)), ])
    }
  }
  return(two_way_table)
}
calculate_mutual_info <- function(x, y, n) {
  columns_sorted <- sort(c(x, y))
  all_two_way_tables_local <- get("all_two_way_tables", 1)
  two_way_table <-
    all_two_way_tables_local[[paste(columns_sorted[1],"-", columns_sorted[2])]]
  mut_info <- 0
  for(i in 1:2){
    for(j in 1:2){
      # 0log(0/0) = 0, 0log(0/>0) = 0 and >0log(>0/0) = infinity
      denominator <- sum(two_way_table[i,]) * sum(two_way_table[, j])
      numerator <- two_way_table[i, j] * n
      if (numerator == 0) {
        mut_info <- mut_info
      } else {
        mut_info <- mut_info + 
          1/n * two_way_table[i, j] * log(numerator / denominator)
      }
  }
  }
  return(mut_info)
}


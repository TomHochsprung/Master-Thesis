examine_results <- function(truth, learned) {
  total_true_edges <- length(truth)
  forgotten_edges <- setdiff(truth, learned)
  number_forgotten_edges <- length(forgotten_edges)
  percentage_forgotten_edges <- number_forgotten_edges / total_true_edges
  wrongly_included_edges <- setdiff(learned, truth)
  number_wrongly_included_edges <- length(wrongly_included_edges)
  return(list("forgotten_edges" = forgotten_edges,
              "wrongly_included_edges" = wrongly_included_edges,
              "number_forgotten_edges" = number_forgotten_edges,
              "percentage_forgotten_edges" = percentage_forgotten_edges,
              "number_wrongly_included_edges" = number_wrongly_included_edges))
}



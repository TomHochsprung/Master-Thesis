paste_chow_liu <- function(edgelist) {
  pasted_cl <- character(nrow(edgelist))
  for(i in 1:nrow(edgelist)){
    pasted_cl[i] <- paste0(edgelist[i, 1],"-", edgelist[i, 2])
  }
  return(pasted_cl)
}
paste_results <- function(result) {
  l <- length(result)
  result_vec <- character(l)
  for (i in 1:l) {
    edge <- sort(result[[i]])
    result_vec[i] <- paste0(edge, collapse = "-")
  }
  return(result_vec)
}






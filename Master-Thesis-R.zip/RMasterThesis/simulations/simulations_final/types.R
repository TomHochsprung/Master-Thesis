
adj_star <- matrix(numeric(l * l), ncol = l)
adj_star[1, ] <- rep(1, l)
adj_star[, 1] <- rep(1, l)
adj_star[1, 1] <- 0
# library(igraph)
# plot(graph_from_adjacency_matrix(adj_star, mode = "undirected"))


adj_chain <- matrix(numeric(l * l), ncol = l)
for(i in 1:l){
  for(j in 1:l){
    if(abs(i - j) == 1){
      adj_chain[i, j] <- 1
    }
  }
}
# library(igraph)
# plot(graph_from_adjacency_matrix(adj_chain, mode = "undirected"))


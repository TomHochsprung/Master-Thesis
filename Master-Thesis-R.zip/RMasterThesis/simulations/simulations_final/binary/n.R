N <- 20
sample_sizes <- c(10, seq(100, 1000, by = 100)) * 10
# sample_sizes <- c(100, 500)
# kappas2 <- c(1, 5, 10) * 10
kappas2 <- 10
nodes <- 1:(100)
l <- length(nodes)
n_hyp <- 40 * 100^2 #not important
# alpha11 <- 0.01
# alpha22 <- 0.01
set.seed(2021)

source("simulations/simulations_final/types.R")
# adj_chain or adj_star
# adj_matrix <- adj_chain
# adj_matrix <- (adj_star + t(adj_star)) / 2
# # # reorder vertices for cholesky
# adj_matrix <- flow_out(adj_matrix, 1) / 2
# adj_matrix <- topSort(adj_matrix)
# 
# # truth is a vector of edges, e.g. "1-2", "2-3", ...
# truth <- paste_chow_liu(adj_matrix)

number_sample_sizes <- length(sample_sizes)

# correct_cases_c_l <- numeric(number_sample_sizes)

empty_matrix <- matrix(numeric(number_sample_sizes * N), nrow = N)

number_forgotten_edges_list2 <- list(empty_matrix, empty_matrix)
number_wrongly_included_edges_list2 <- list(empty_matrix, empty_matrix)
n_entries_queried_list2 <- list(empty_matrix, empty_matrix)
correct_cases_list2 <- list(empty_matrix, empty_matrix)
duration_list2 <- list(empty_matrix, empty_matrix)
shd_list2 <- list(empty_matrix, empty_matrix)
iter_list2 <- list(empty_matrix, empty_matrix)
for(i2 in 1:N){
  adj_matrix <- prufer(l)
  adj_matrix <- flow_out(adj_matrix, 1) / 2
  adj_matrix <- topSort(adj_matrix)
  truth <- paste_chow_liu(adj_matrix)
  Sigma <- generate_by_cholesky(adj_matrix, epsilon = 2)
  # mu <- runif(l, min = 0.4, max = 0.6)
  
  # Sigma <- cov_from_adj(adj_matrix)[[1]]
  print(i2)
for(n in sample_sizes){
  alpha11 <- 5e-4
  alpha22 <- 5e-4
  # alpha11 <- max(2*(1 - pnorm(3.28 * (n / l)^0.5 / 2)), 2 * sqrt(.Machine$double.eps))
  # alpha22 <- max(2*(1 - pnorm(3.28 * (n / l)^0.5 / 2)), 2 * sqrt(.Machine$double.eps))
  j2 <- which(n == sample_sizes)
 print(j2)
  
    # simulate_no_ram(n, Sigma = Sigma, type = "binary", mu = mu)
    print("sim_done")
    # Chow-Liu
    all_g2s <- calculate_all(l)
    all_two_way_tables <- calculate_all_two_way_tables(l)
    all_mutual_infos <- calculate_all_mutual_infos(l, n)
    # load(paste0("simulations/simulations_final/binary/saved_lists/bu_",i2 ,"_sample_size_", j2, ".Rdata"))
    # all_names <- lapply(three_way_quantities, `[[`, 1)
    print(paste0("alphas: ",alpha11,"; ", alpha22))
    all_three_way_tables <- lapply(three_way_quantities, `[[`, 2)
    all_g2s <- lapply(three_way_quantities, `[[`, 3)
    
    print("cl_start")
      result_c_l <- chow_liu(l, n, type = "binary")
    adj_matrix_c_l <- result_c_l$adj_matrix
    pasted_c_l <- paste_chow_liu(adj_matrix_c_l)
    examined_c_l <- examine_results(truth, pasted_c_l)
    number_forgotten_edges_list2[[1]][i2, j2] <- examined_c_l$number_forgotten_edges
    number_wrongly_included_edges_list2[[1]][i2, j2] <- examined_c_l$number_wrongly_included_edges
    duration_list2[[1]][i2, j2] <- as.numeric(result_c_l$t_diff)
    shd_list2[[1]][i2, j2] <- examined_c_l$number_forgotten_edges + examined_c_l$number_wrongly_included_edges
    correct_cases_list2[[1]][i2, j2] <- 1 * ((examined_c_l$number_forgotten_edges == 0) && (examined_c_l$number_wrongly_included_edges==0))
    n_entries_queried_list2[[1]][i2,j2] <- l * (l-1) / 2
    print("Chow-Liu: Finished")
    # RTS_B_kappa
    for(type in c("N")){
      for(kappa in kappas2){
        t <- which(c("B", "H", "N") == type)
        m <- which(kappa == kappas2)
        if (type == "B") {
          sCentral <- "Bonferroni"
          adjustment <- "Bonf"
          withWarmStarts <- TRUE
        } else if (type == "H") {
          sCentral <- "Holm"
          withWarmStarts <- TRUE
        } else if (type == "N") {
          sCentral <- "Bonferroni"
          adjustment <- "Unadjusted"
          withWarmStarts <- FALSE
        }
        queries <- character()
        result <- warm_start_binary(nodes, l, n, n_hyp, alpha1=alpha11, alpha2=alpha22, kappa = kappa, maxiter = 3, sCentral = sCentral, adjustment = adjustment, gFWER = 1, withWarmStarts = withWarmStarts)
        queries <- unique(queries)
        pasted <- paste_results(result$E_hat)
        examined <- examine_results(truth, pasted)
        number_forgotten_edges_list2[[m + 1]][i2, j2] <- examined$number_forgotten_edges
        number_wrongly_included_edges_list2[[m + 1]][i2, j2] <- examined$number_wrongly_included_edges
        duration_list2[[m + 1]][i2, j2] <- as.numeric(result$t_diff)
        shd_list2[[m + 1]][i2, j2] <- examined$number_forgotten_edges + examined$number_wrongly_included_edges
        correct_cases_list2[[m + 1]][i2, j2] <- 1 * ((examined$number_forgotten_edges == 0) && (examined$number_wrongly_included_edges==0))
        n_entries_queried_list2[[m + 1]][i2,j2] <- length(queries)
        iter_list2[[m + 1]][i2, j2] <- result$iter
      }
    }
    save.image("simulations/simulations_final/backup.RData")
  }
}


    
    frac_correct_cases <- colMeans(correct_cases_list2[[1]])
    se_correct_cases <- apply(correct_cases_list2[[1]], 2, sd) / (N^0.5)
    avg_number_forgotten_edges <- colMeans(number_forgotten_edges_list2[[1]])
    se_number_forgotten_edges <- apply(number_forgotten_edges_list2[[1]], 2, sd) / (N^0.5)
    avg_number_wrongly_included_edges <- colMeans(number_wrongly_included_edges_list2[[1]])
    se_number_wrongly_included_edges <- apply(number_wrongly_included_edges_list2[[1]], 2, sd) / (N^0.5)
    avg_n_entries_queried <- colMeans(n_entries_queried_list2[[1]])
    se_n_entries_queried <- apply(n_entries_queried_list2[[1]], 2, sd) / (N^0.5)
    avg_duration <- colMeans(duration_list2[[1]])
    se_duration <- apply(duration_list2[[1]], 2, sd) / (N^0.5)
    avg_shd <- colMeans(shd_list2[[1]])
    se_shd <- apply(shd_list2[[1]], 2, sd) / (N^0.5)
    iter <- colMeans(iter_list2[[1]])
    se_iter <- apply(iter_list2[[1]], 2, sd) / (N^0.5)
    
    
    df_forgotten_edges_new <- data.frame("n" = sample_sizes, "avg_number_forgotten_edges" = avg_number_forgotten_edges, "se_number_forgotten_edges" = se_number_forgotten_edges, "label" = "CL")
    df_wrongly_included_edges_new <- data.frame("n" = sample_sizes, "avg_number_wrongly_included_edges" = avg_number_wrongly_included_edges, "se_number_wrongly_included_edges" = se_number_wrongly_included_edges, "label" = "CL")
    df_shd_new <- data.frame("n" = sample_sizes, "shd" = avg_shd, "se_shd" = se_shd, "label" = "CL")
    df_frac_correct_cases_new <- data.frame("n" = sample_sizes, "frac_correct_cases" = frac_correct_cases,"se_correct_cases" = se_correct_cases, "label" = "CL")
    df_n_entries_queried_new <- data.frame("n" = sample_sizes, "avg_n_entries_queried" = avg_n_entries_queried, "se_n_entries_queried" = se_n_entries_queried, "label" = "CL")
    df_duration_new <- data.frame("n" = sample_sizes, "duration" = avg_duration, "se_duration" = se_duration, "label" = "CL")
    df_iter_new <- data.frame("n" = sample_sizes, "duration" = iter, "se_duration" = se_iter, "label" = "CL")
    

      
    df_forgotten_edges <- df_forgotten_edges_new
    df_wrongly_included_edges <- df_wrongly_included_edges_new 
    df_shd<-df_shd_new
    df_frac_correct_cases <- df_frac_correct_cases_new
    df_n_entries_queried <- df_n_entries_queried_new
    df_duration <- df_duration_new
    df_iter <- df_iter_new
        


for(type in c("N")){
  for(kappa in kappas2){
    t <- which(c("B", "H", "N") == type)
    m <- which(kappa == kappas2)
    frac_correct_cases <- colMeans(correct_cases_list2[[m + 1]])
    se_correct_cases <- apply(correct_cases_list2[[m + 1]], 2, sd) / (N^0.5)
    avg_number_forgotten_edges <- colMeans(number_forgotten_edges_list2[[m + 1]])
    se_number_forgotten_edges <- apply(number_forgotten_edges_list2[[m + 1]], 2, sd) / (N^0.5)
    avg_number_wrongly_included_edges <- colMeans(number_wrongly_included_edges_list2[[m + 1]])
    se_number_wrongly_included_edges <- apply(number_wrongly_included_edges_list2[[m + 1]], 2, sd) / (N^0.5)
    avg_n_entries_queried <- colMeans(n_entries_queried_list2[[m + 1]])
    se_n_entries_queried <- apply(n_entries_queried_list2[[m + 1]], 2, sd) / (N^0.5)
    avg_duration <- colMeans(duration_list2[[m + 1]])
    se_duration <- apply(duration_list2[[m + 1]], 2, sd) / (N^0.5)
    avg_shd <- colMeans(shd_list2[[m + 1]])
    se_shd <- apply(shd_list2[[m + 1]], 2, sd) / (N^0.5)
    iter <- colMeans(iter_list2[[m + 1]])
    se_iter <- apply(iter_list2[[m + 1]], 2, sd) / (N^0.5)
    
    
    df_forgotten_edges_new <- data.frame("n" = sample_sizes, "avg_number_forgotten_edges" = avg_number_forgotten_edges, "se_number_forgotten_edges" = se_number_forgotten_edges, "label" = paste0("RTS_",type ,"_", kappa))
    df_wrongly_included_edges_new <- data.frame("n" = sample_sizes, "avg_number_wrongly_included_edges" = avg_number_wrongly_included_edges, "se_number_wrongly_included_edges" = se_number_wrongly_included_edges, "label" = paste0("RTS_",type ,"_", kappa))
    df_shd_new <- data.frame("n" = sample_sizes, "shd" = avg_shd, "se_shd" = se_shd, "label" = paste0("RTS_",type ,"_", kappa))
    df_frac_correct_cases_new <- data.frame("n" = sample_sizes, "frac_correct_cases" = frac_correct_cases,"se_correct_cases" = se_correct_cases, "label" = paste0("RTS_",type ,"_", kappa))
    df_n_entries_queried_new <- data.frame("n" = sample_sizes, "avg_n_entries_queried" = avg_n_entries_queried, "se_n_entries_queried" = se_n_entries_queried, "label" = paste0("RTS_",type ,"_", kappa))
    df_duration_new <- data.frame("n" = sample_sizes, "duration" = avg_duration, "se_duration" = se_duration, "label" = paste0("RTS_",type ,"_", kappa))
    df_iter_new <- data.frame("n" = sample_sizes, "duration" = iter, "se_duration" = se_iter, "label" = paste0("RTS_",type ,"_", kappa))
    

      
      df_forgotten_edges <- rbind(df_forgotten_edges, df_forgotten_edges_new)
      df_wrongly_included_edges <- rbind(df_wrongly_included_edges, df_wrongly_included_edges_new)
      df_shd <- rbind(df_shd, df_shd_new)
      df_frac_correct_cases <- rbind(df_frac_correct_cases, df_frac_correct_cases_new)
      df_n_entries_queried <- rbind(df_n_entries_queried, df_n_entries_queried_new)
      df_duration <- rbind(df_duration, df_duration_new)
      df_iter <- rbind(df_iter, df_iter_new)
      
      
      
    
  }
}
set.seed(2021)
N <- 20
sample_sizes <- c(10, seq(100, 1000, by = 100)) * 10
kappas <- c(1, 5, 10) * 10
nodes <- 1:(100)
l <- length(nodes)
number_sample_sizes <- length(sample_sizes)
empty_matrix <- matrix(numeric(number_sample_sizes * N), nrow = N)
for(i in 1:N){
  adj_matrix <- prufer(l)
  adj_matrix <- flow_out(adj_matrix, 1) / 2
  adj_matrix <- topSort(adj_matrix)
  truth <- paste_chow_liu(adj_matrix)
  Sigma <- generate_by_cholesky(adj_matrix, epsilon = 2)
  mu <- runif(l, min = 0.4, max = 0.6)
  print(i)
  for(n in sample_sizes){
    j <- which(n == sample_sizes)
    print(j)
    simulate_no_ram(n, Sigma = Sigma, type = "binary", mu = mu)
    print("sim_done")
    # Chow-Liu
    dat <- fread(input = "simulations/data_storage/data.csv", skip = 1, data.table = FALSE)
    combis <- combn(1:l, 3, simplify = FALSE)
    all_combis <- do.call(rbind, combis)
    three_way_quantities <- mcmapply(FUN= g2, all_combis[, 1], all_combis[, 2], all_combis[, 3], SIMPLIFY = FALSE)
    names(three_way_quantities) <- unlist(mclapply(three_way_quantities, `[[`, 1))
    all_two_way_tables <- calculate_all_two_way_tables(l)
    all_mutual_infos <- calculate_all_mutual_infos(l, n)
    save.image(file = paste0("simulations/simulations_final/binary/saved_lists/bu_",i ,"_sample_size_", j, ".Rdata"))
  }
}

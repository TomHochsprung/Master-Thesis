# 1: Sigma_hat known beforehand
# 2: Sigma_hat not known beforehand, calculate entry only if needed by reading in all data at once
# 3: Sigma_hat not known beforehand, calculate entry only if needed by using the welford algorithm
approach <- 1

N <- 20
n <- 500
alphas <- c(1e-5, 1e-4, 1e-3, 1e-2, 1e-1)
kappas <- c(1, 5, 10) * 10
nodes <- 1:(10 * 10)
l <- length(nodes)
n_hyp <- 40 * 100^2 #not important
# alpha1 <- 0.01
# alpha2 <- 0.01
set.seed(2021)

source("matrices/types.R")
# adj_chain or adj_star
# adj_matrix <- adj_chain
# adj_matrix <- (adj_star + t(adj_star)) / 2
# # # reorder vertices for cholesky
# adj_matrix <- flow_out(adj_matrix, 1) / 2
# adj_matrix <- topSort(adj_matrix)
# 
# # truth is a vector of edges, e.g. "1-2", "2-3", ...
# truth <- paste_chow_liu(adj_matrix)

number_alphas <- length(alphas)

# correct_cases_c_l <- numeric(number_alphas)

empty_matrix <- matrix(numeric(number_alphas * N), nrow = N)

number_forgotten_edges_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
number_wrongly_included_edges_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
frac_entries_queried_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
correct_cases_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
duration_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
shd_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
iter_list <- list(empty_matrix, empty_matrix, empty_matrix, empty_matrix)
for(i in 1:N){
  adj_matrix <- prufer(l)
  adj_matrix <- flow_out(adj_matrix, 1) / 2
  adj_matrix <- topSort(adj_matrix)
  truth <- paste_chow_liu(adj_matrix)
  Sigma <- generate_by_cholesky(adj_matrix) 
  # Sigma <- cov_from_adj(adj_matrix)[[1]]
  print(i)
  for(alpha1 in alphas){
    alpha2 <- 5e-4
    # alpha2 <- 5e-2
    # alpha1 <- max(2*(1 - pnorm(3.28 * (n / l)^0.5 / 2)), 2 * sqrt(.Machine$double.eps))
    # alpha2 <- max(2*(1 - pnorm(3.28 * (n / l)^0.5 / 2)), 2 * sqrt(.Machine$double.eps))
    j <- which(alpha1 == alphas)
    print(j)
    
    simulate_no_ram(n, Sigma = Sigma, batchsize = n)
    
    # Chow-Liu
    if (approach == 1){
      X <- fread(input = "simulations/data_storage/data.csv", skip = 1, data.table = FALSE)
      Sigma_hat <- cov(X)
      result_c_l <- chow_liu(l, n, Sigma_hat)
    } else {
      Sigma_hat <- matrix(rep(NA, l * l), ncol = l)
      result_c_l <- chow_liu(l, n, NULL)
    }
    adj_matrix_c_l <- result_c_l$adj_matrix
    pasted_c_l <- paste_chow_liu(adj_matrix_c_l)
    examined_c_l <- examine_results(truth, pasted_c_l)
    number_forgotten_edges_list[[1]][i, j] <- examined_c_l$number_forgotten_edges
    number_wrongly_included_edges_list[[1]][i, j] <- examined_c_l$number_wrongly_included_edges
    duration_list[[1]][i, j] <- as.numeric(result_c_l$t_diff)
    shd_list[[1]][i, j] <- examined_c_l$number_forgotten_edges + examined_c_l$number_wrongly_included_edges
    correct_cases_list[[1]][i, j] <- 1 * ((examined_c_l$number_forgotten_edges == 0) && (examined_c_l$number_wrongly_included_edges==0))
    frac_entries_queried_list[[1]][i,j] <- 1
    print("Chow-Liu: Finished")
    
    # RTS_B_kappa
    for(type in c("N")){
      for(kappa in kappas){
        t <- which(c("B", "H", "N") == type)
        m <- which(kappa == kappas)
        print(m + 1)
        if (type == "B") {
          sCentral <- "Bonferroni"
          adjustment <- "Bonf"
          withWarmStarts <- TRUE
        } else if (type == "H") {
          sCentral <- "Holm"
          withWarmStarts <- TRUE
        } else if (type == "N") {
          sCentral <- "Bonferroni"
          adjustment <- "Unadjusted"
          withWarmStarts <- FALSE
        }
        query_matrix <- matrix(numeric(l * l), ncol = l)
        result <- warm_start(nodes, l, n, n_hyp, alpha1=alpha1, alpha2=alpha2, kappa = kappa, maxiter = 3, sCentral = sCentral, adjustment = adjustment, gFWER = 1, withWarmStarts = withWarmStarts)
        pasted <- paste_results(result$E_hat)
        examined <- examine_results(truth, pasted)
        number_forgotten_edges_list[[m + 1]][i, j] <- examined$number_forgotten_edges
        number_wrongly_included_edges_list[[m + 1]][i, j] <- examined$number_wrongly_included_edges
        duration_list[[m + 1]][i, j] <- as.numeric(result$t_diff)
        shd_list[[m + 1]][i, j] <- examined$number_forgotten_edges + examined$number_wrongly_included_edges
        correct_cases_list[[m + 1]][i, j] <- 1 * ((examined$number_forgotten_edges == 0) && (examined$number_wrongly_included_edges==0))
        frac_entries_queried_list[[m + 1]][i,j] <- sum(query_matrix == 1) / (l * (l+1) / 2)
        iter_list[[m + 1]][i, j] <- result$iter
      }
    }
    save.image("simulations/simulations_final/backup.RData")
  }
}



frac_correct_cases <- colMeans(correct_cases_list[[1]])
se_correct_cases <- apply(correct_cases_list[[1]], 2, sd) / (N^0.5)
avg_number_forgotten_edges <- colMeans(number_forgotten_edges_list[[1]])
se_number_forgotten_edges <- apply(number_forgotten_edges_list[[1]], 2, sd) / (N^0.5)
avg_number_wrongly_included_edges <- colMeans(number_wrongly_included_edges_list[[1]])
se_number_wrongly_included_edges <- apply(number_wrongly_included_edges_list[[1]], 2, sd) / (N^0.5)
avg_fraction_entries_queried <- colMeans(frac_entries_queried_list[[1]])
se_fraction_entries_queried <- apply(frac_entries_queried_list[[1]], 2, sd) / (N^0.5)
avg_duration <- colMeans(duration_list[[1]])
se_duration <- apply(duration_list[[1]], 2, sd) / (N^0.5)
avg_shd <- colMeans(shd_list[[1]])
se_shd <- apply(shd_list[[1]], 2, sd) / (N^0.5)
iter <- colMeans(iter_list[[1]])
se_iter <- apply(iter_list[[1]], 2, sd) / (N^0.5)


df_forgotten_edges_new <- data.frame("alpha" = alphas, "avg_number_forgotten_edges" = avg_number_forgotten_edges, "se_number_forgotten_edges" = se_number_forgotten_edges, "label" = "CL")
df_wrongly_included_edges_new <- data.frame("alpha" = alphas, "avg_number_wrongly_included_edges" = avg_number_wrongly_included_edges, "se_number_wrongly_included_edges" = se_number_wrongly_included_edges, "label" = "CL")
df_shd_new <- data.frame("alpha" = alphas, "shd" = avg_shd, "se_shd" = se_shd, "label" = "CL")
df_frac_correct_cases_new <- data.frame("alpha" = alphas, "frac_correct_cases" = frac_correct_cases,"se_correct_cases" = se_correct_cases, "label" = "CL")
df_fraction_entries_queried_new <- data.frame("alpha" = alphas, "avg_fraction_entries_queried" = avg_fraction_entries_queried, "se_fraction_entries_queried" = se_fraction_entries_queried, "label" = "CL")
df_duration_new <- data.frame("alpha" = alphas, "duration" = avg_duration, "se_duration" = se_duration, "label" = "CL")
df_iter_new <- data.frame("alpha" = alphas, "duration" = iter, "se_duration" = se_iter, "label" = "CL")



df_forgotten_edges <- df_forgotten_edges_new
df_wrongly_included_edges <- df_wrongly_included_edges_new 
df_shd<-df_shd_new
df_frac_correct_cases <- df_frac_correct_cases_new
df_fraction_entries_queried <- df_fraction_entries_queried_new
df_duration <- df_duration_new
df_iter <- df_iter_new



for(type in c("N")){
  for(kappa in kappas){
    t <- which(c("B", "H", "N") == type)
    m <- which(kappa == kappas)
    print(m + 1)
    frac_correct_cases <- colMeans(correct_cases_list[[m + 1]])
    se_correct_cases <- apply(correct_cases_list[[m + 1]], 2, sd) / (N^0.5)
    avg_number_forgotten_edges <- colMeans(number_forgotten_edges_list[[m + 1]])
    se_number_forgotten_edges <- apply(number_forgotten_edges_list[[m + 1]], 2, sd) / (N^0.5)
    avg_number_wrongly_included_edges <- colMeans(number_wrongly_included_edges_list[[m + 1]])
    se_number_wrongly_included_edges <- apply(number_wrongly_included_edges_list[[m + 1]], 2, sd) / (N^0.5)
    avg_fraction_entries_queried <- colMeans(frac_entries_queried_list[[m + 1]])
    se_fraction_entries_queried <- apply(frac_entries_queried_list[[m + 1]], 2, sd) / (N^0.5)
    avg_duration <- colMeans(duration_list[[m + 1]])
    se_duration <- apply(duration_list[[m + 1]], 2, sd) / (N^0.5)
    avg_shd <- colMeans(shd_list[[m + 1]])
    se_shd <- apply(shd_list[[m + 1]], 2, sd) / (N^0.5)
    iter <- colMeans(iter_list[[m + 1]])
    se_iter <- apply(iter_list[[m + 1]], 2, sd) / (N^0.5)
    
    
    df_forgotten_edges_new <- data.frame("alpha" = alphas, "avg_number_forgotten_edges" = avg_number_forgotten_edges, "se_number_forgotten_edges" = se_number_forgotten_edges, "label" = paste0("RTS_",type ,"_", kappa))
    df_wrongly_included_edges_new <- data.frame("alpha" = alphas, "avg_number_wrongly_included_edges" = avg_number_wrongly_included_edges, "se_number_wrongly_included_edges" = se_number_wrongly_included_edges, "label" = paste0("RTS_",type ,"_", kappa))
    df_shd_new <- data.frame("alpha" = alphas, "shd" = avg_shd, "se_shd" = se_shd, "label" = paste0("RTS_",type ,"_", kappa))
    df_frac_correct_cases_new <- data.frame("alpha" = alphas, "frac_correct_cases" = frac_correct_cases,"se_correct_cases" = se_correct_cases, "label" = paste0("RTS_",type ,"_", kappa))
    df_fraction_entries_queried_new <- data.frame("alpha" = alphas, "avg_fraction_entries_queried" = avg_fraction_entries_queried, "se_fraction_entries_queried" = se_fraction_entries_queried, "label" = paste0("RTS_",type ,"_", kappa))
    df_duration_new <- data.frame("alpha" = alphas, "duration" = avg_duration, "se_duration" = se_duration, "label" = paste0("RTS_",type ,"_", kappa))
    df_iter_new <- data.frame("alpha" = alphas, "duration" = iter, "se_duration" = se_iter, "label" = paste0("RTS_",type ,"_", kappa))
    
    
    
    df_forgotten_edges <- rbind(df_forgotten_edges, df_forgotten_edges_new)
    df_wrongly_included_edges <- rbind(df_wrongly_included_edges, df_wrongly_included_edges_new)
    df_shd <- rbind(df_shd, df_shd_new)
    df_frac_correct_cases <- rbind(df_frac_correct_cases, df_frac_correct_cases_new)
    df_fraction_entries_queried <- rbind(df_fraction_entries_queried, df_fraction_entries_queried_new)
    df_duration <- rbind(df_duration, df_duration_new)
    df_iter <- rbind(df_iter, df_iter_new)
    
    
    
    
  }
}
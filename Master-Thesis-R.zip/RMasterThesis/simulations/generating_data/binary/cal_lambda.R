cal_lambda <- function(vec, bin_cor, by = 2e-3) {
  rho <- seq(-(1 - by),(1-by), by = by)
  vals <- numeric(length(rho))
  for(i in 1:length(rho)) {
    vals[i] <- abs(bin_cor - pmvnorm(upper = vec[1:2],
                                     mean = c(0,0),
                                     corr = matrix(c(1, rho[i], rho[i], 1),
                                                   ncol = 2,
                                                   byrow = TRUE)) +
                     pnorm(vec[1])*pnorm(vec[2]))
  }
  arg_min <- which(min(vals) == vals)
  return(rho[arg_min[1]])
}
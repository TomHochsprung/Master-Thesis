generate_binary <- function(n, adj_matrix, epsilon = 10, max_iter = 5) {
  for(i in 1:max_iter){
    if(i == max_iter){
      print("Max_iter!")
    }
    Sigma <- generate_by_cholesky(adj_matrix, epsilon = epsilon)
    Sigma <- Sigma / abs(sum(diag(Sigma)))
    tf <- transform_binary_to_normal(Sigma)
    gamma <- tf$gamma
    Lambda <- tf$Lambda
    print(Lambda)
    print(eigen(Lambda)$values)
    if(min(eigen(Lambda)$values) > 0){
      U <- mvrnorm(n, mu = gamma, Sigma = Lambda)
      X <- (U > 0) * 1
      break
    }
  }
  return(X)
}

transform_binary_to_normal <- function(Sigma) {
  gamma <- cal_mu(Sigma)
  Lambda<- diag(rep(1, length(gamma)))
  for(i in 1:length(gamma)){
    for(j in 1:length(gamma)){
      if(i != j){
        Lambda[i, j] <- cal_lambda(gamma[c(i, j)], Sigma[i, j])
      }
    }
  }
  return(list("gamma" = gamma, "Lambda" = Lambda))
}
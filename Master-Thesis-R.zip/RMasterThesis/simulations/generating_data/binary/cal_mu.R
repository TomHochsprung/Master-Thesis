cal_mu <- function(Sigma , by = 2e-1){
  Sigma_diag <- diag(Sigma)
  minimizers <- numeric(length(Sigma_diag))
  for(i in 1:length(Sigma_diag)){
    gamma_seq <- seq(-10, 10, by = by)
    vals <- numeric(length(gamma_seq))
    for(j in 1:length(gamma_seq)){
      vals[j] <- abs(Sigma_diag[i] - pnorm(gamma_seq[j])*pnorm(-gamma_seq[j]))
    }
    arg_min <- which(min(vals) == vals)
    minimizers[i] <- gamma_seq[arg_min[1]]
  }
  return(minimizers)
}
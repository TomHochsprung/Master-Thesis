simulate_no_ram <- function(n,
                            Sigma,
                            batchsize = n,
                            path = "simulations/data_storage",
                            type = "normal",
                            mu = NULL) {
  if(file.exists(paste0(path, "/data.csv"))) {
    file.remove(paste0(path, "/data.csv"))
  }
  l <- dim(Sigma)[1]
  for (i in 1:(n/batchsize)) {
    if(type == "normal") {
      X <- mvrnorm(batchsize, mu = rep(0, l), Sigma = Sigma)
    } else {
      Rho <- cov2cor(Sigma)
      X <- rmvbin(batchsize, margprob = mu, bincorr = Rho)
    }
    write.table(X,
                paste0(path, "/data.csv"),
                sep = ",",
                row.names = FALSE,
                col.names = !file.exists(paste0(path, "/data.csv")),
                append = TRUE)
  }
}

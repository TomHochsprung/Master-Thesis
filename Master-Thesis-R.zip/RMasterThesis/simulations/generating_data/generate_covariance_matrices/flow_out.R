flow_out <- function(adj_matrix, root_node) {
  adj_matrix[which(adj_matrix[, root_node] != 2), root_node] <- 0
  nbs <- which(adj_matrix[root_node, ] == 1)
  adj_matrix[root_node, which(adj_matrix[root_node, ] == 1)] <- 2
  for (node in nbs) {
    adj_matrix <- flow_out(adj_matrix, node)
  }
  return(adj_matrix)
}

make_matrix_positive_definite <- function(matrix, epsilon){
  for(i in 1:nrow(matrix)){
    sum_row <- 0
    for(j in 1:ncol(matrix)){
      if(i==j){
        next
      }
      sum_row <- sum_row + abs(matrix[i,j])
    }
    matrix[i,i] <- sum_row + epsilon
  }
  return(matrix)
}
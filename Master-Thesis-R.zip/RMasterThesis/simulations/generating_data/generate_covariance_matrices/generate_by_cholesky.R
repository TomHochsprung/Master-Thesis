generate_by_cholesky <- function(adj_matrix, epsilon = 1, min = 0.1, max = 1) {
  d <- dim(adj_matrix)[1]
  K <- matrix(numeric(d * d), nrow = d)
  adj_new <- adj_matrix
  for(j in 1:d){
    for(i in 1:d){
      if (adj_new[i, j] == 1){
        v <- sign(runif(1, -1, 1))
        K[i,j] <- runif(1, min = min, max = max) * v
      }
    }
  }
  K <- K + diag(rep(epsilon,d))
  K <- K %*% t(K)
  Sigma <- solve(K)
  return(Sigma)
}





cov_from_adj <- function(adj_matrix, min = 0.1, max = 1, epsilon = 1) {
  for(i in 1:nrow(adj_matrix)){
    for(j in 1:i){
      if(adj_matrix[i,j]==1){
        v <- sign(runif(1, -1, 1))
        u <- runif(1, min, max)
        adj_matrix[i,j] <- u * v
        adj_matrix[j,i] <- u * v
      }
    }
  }
  matrix_list <- list()
  for (i in 1:length(epsilon)) {
   K <- make_matrix_positive_definite(adj_matrix, epsilon[i])
   cov_matrix <- solve(K)
   matrix_list[[i]] <- cov_matrix
  }
  return(matrix_list)
}
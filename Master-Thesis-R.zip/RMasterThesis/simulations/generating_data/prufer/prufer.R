## Wu, B: Spanning Trees and Optimization Problems
prufer <- function(k){

P_orig <- ceiling(runif(k-2, min = 0, max = k))
P <- P_orig
V_orig <- 1:k
V <- V_orig
adj_matrix <- matrix(numeric(k * k), ncol = k)

for(i in 1:(k-2)){
	complement <- setdiff(V, P)
	v_0 <- min(complement)
	V <- setdiff(V, v_0)
	adj_matrix[which(V_orig == v_0), which(V_orig == P_orig[i])] <- 1
	adj_matrix[which(V_orig == P_orig[i]), which(V_orig == v_0)] <- 1
	P <- P[2:length(P)]
}

adj_matrix[which(V_orig == V[1]), which(V_orig == V[2])] <- 1
adj_matrix[which(V_orig == V[2]), which(V_orig == V[1])] <- 1


return(adj_matrix)

}

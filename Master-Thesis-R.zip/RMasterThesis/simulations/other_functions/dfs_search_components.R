dfs_search_components_visit <- function(adj_matrix, root_node, colours, predecessors){
  nbs <- which(adj_matrix[root_node, ] == 1)
  colours[root_node] <- "Grey"
  n_vertices <- 1
  for(nb in nbs){
    if(colours[nb] == "White"){
      predecessors[nb] <- root_node
      result <- dfs_search_components_visit(adj_matrix, nb, colours, predecessors)
      colours <- result$colours
      predecessors <- result$predecessors
      n_vertices <- result$n_vertices + n_vertices
      
    }
  }
  colours[root_node] <- "Black"
  return(list("colours" = colours, "predecessors" = predecessors, "n_vertices" = n_vertices))
}


dfs_search_components <- function(adj_matrix){
  l <- dim(adj_matrix)[1]
  colours <- rep("White", l)
  subtree_sizes <- numeric(0)
  for (i in 1:l){
    if (colours[i] == "White"){
      result <- dfs_search_components_visit(adj_matrix, i, rep("White", l), character(l))
      subtree_sizes <- c(subtree_sizes, result$n_vertices)
      colours <- result$colours
    }
  }
  return(subtree_sizes)
}


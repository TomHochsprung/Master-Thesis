calculate_cov <- function(n, x_pos, y_pos, type = "Usual", path = "simulations/data_storage/data.csv"){
  
  if(type == "Usual") {
    dat <- fread(input = "simulations/data_storage/data.csv", skip = 1, select = unique(c(x_pos, y_pos)), data.table = FALSE)
    if(x_pos == y_pos){
      value <- as.numeric(cov(dat[, 1, drop = FALSE]))
    } else {
      value <- as.numeric(cov(dat[, 1], dat[, 2]))
    }
    
  } else if (type == "Welford") {
    value <- welford_alg(n, x_pos, y_pos, path = path)
  }
#   cov_matrix <- matrix(numeric(l * l), ncol = l, nrow = l)
#   
#   for (i in 1:l){
#     for(j in 1:l){
#       cov_matrix[i, j] <- welford_alg(n, i, j, X)
#     }
#   }
#   return(cov_matrix)
  return(value)
}

# calculate_cov(10000, 1, 1, "Welford")
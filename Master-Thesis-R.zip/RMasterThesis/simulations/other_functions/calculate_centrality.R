calculate_centrality <- function(adj_matrix){
  l <- dim(adj_matrix)[1]
  cent <- numeric(l)
  for(i in 1:l){
    adj_matrix_new <- adj_matrix
    adj_matrix_new[i, ] <- numeric(l)
    adj_matrix_new[, i] <- numeric(l)
    cent[i] <- max(dfs_search_components(adj_matrix_new))
  }
  cent <- cent / (l - 1)
  return(cent)
}
# calculate_centrality(adj_matrix - diag(diag(adj_matrix)))
# plot(graph_from_adjacency_matrix(calculate_centrality(adj_matrix - diag(diag(adj_matrix)))))
# plot(graph_from_adjacency_matrix(adj_matrix - diag(diag(adj_matrix))))

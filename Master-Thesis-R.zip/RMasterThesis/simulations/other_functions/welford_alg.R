welford_alg <- function(n,
                        x_pos,
                        y_pos,
                        path = "simulations/data_storage/data.csv") {
  data <- fread(input = "simulations/data_storage/data.csv", nrow = 1, skip = 1, select = unique(c(x_pos, y_pos)), data.table = FALSE)
  # print(data)
  x <- data[, 1]
  if (x_pos != y_pos){
    y <- data[, 2]
  } else {
    y <- x
  }
  x_bar <- x
  y_bar <- y
  S <- 0
  for(i in 2:n){
    data <- fread(input = "simulations/data_storage/data.csv", nrow = 1, skip = i, select = unique(c(x_pos, y_pos)), data.table = FALSE)
    x <- data[, 1]
    if (x_pos != y_pos){
      y <- data[, 2]
    } else {
      y <- x
    }
    S <- S + (i - 1) / i * (x - x_bar) * (y - y_bar)
    x_bar <- (i - 1) / i * x_bar + 1 / i * x
    y_bar <- (i - 1) / i * y_bar + 1 / i * x
  }
  # S is sum of squares
  return(S / (n - 1))
}
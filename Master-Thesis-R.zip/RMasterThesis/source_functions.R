all_files <- list.files(pattern = "[.]R$", recursive = TRUE)
files_to_exclude <- "source_functions.R"
setwd("/home/rstudio/RMasterThesis/simulations/simulations_final")
files_to_exclude <- c(paste0("simulations/simulations_final/", list.files(pattern = "[.]R$", recursive = TRUE)), files_to_exclude)
setwd("/home/rstudio/RMasterThesis")
files_to_exclude
files_to_source <- setdiff(all_files, files_to_exclude)
files_to_source
lapply(files_to_source, source)

g2 <- function(x, y, z) {
  dat_local <- get("dat", 1)
  # dat_local <- fread(input = "simulations/dat_locala_storage/dat_locala.csv", skip = 1, select = unique(c(x, y, z)), dat_locala.table = FALSE)
  three_way_table <- array(0, c(2, 2, 2))
  g2 <- 0
  for(i in 1:2){
    for(j in 1:2){
      for(k in 1:2){
        three_way_table[i, j, k] <- nrow(dat_local[(dat_local[, x] == (i - 1)) & (dat_local[, y] == (j - 1)) & (dat_local[, z] == (k - 1)), ])
        denominator <- sum(three_way_table[i, ,k]) * sum(three_way_table[, j, k])
        numerator <- three_way_table[i, j, k] * sum(three_way_table[, , k])
        if (numerator == 0){
          g2 <- g2
        } else {
          g2 <- g2 + three_way_table[i, j, k] * log(numerator / denominator)
        }
      }
    }
  }
  g2 <- 2 * g2
  return(list("name" = paste(x,"-", y, "-", z),
              "three_way_table" = three_way_table,
              "g2" = g2))
}


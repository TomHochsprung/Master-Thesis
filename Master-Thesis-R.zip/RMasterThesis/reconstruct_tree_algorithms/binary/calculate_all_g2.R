calculate_all_g2 <- function(l) {
  g2_list <- list()
  # for(i in 3:l){
  #   for(j in 2:(i - 1)) {
  #     for(k in 1:(j - 1)) {
  #       new_g2 <-  g2(k, j, i)
  #       #print(new_g2)
  #       g2_list[[length(g2_list) + 1]] <- new_g2
  #       #print(g2_list)
  #       #print(names(g2_list))
  #       names(g2_list)[length(g2_list)] <- paste(k,"-", j, "-", i)
  #     }
  #   }
  # }
  # g2_list <- mapply(g2, all_combis[, 1], all_combis[, 2], all_combis[, 3], SIMPLIFY = FALSE)
  return(g2_list)
}
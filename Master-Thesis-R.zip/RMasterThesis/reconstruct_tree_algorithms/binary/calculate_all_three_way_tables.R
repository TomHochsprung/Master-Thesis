calculate_all <- function(l) {
  t1 <- Sys.time()
  tables_list <- list()
  g2_list <- list()
  for(i in 3:l){
    print(paste0("outer1",i))
    print(Sys.time() - t1)
    for(j in 2:(i - 1)) {
      for(k in 1:(j - 1)) {
        new_table <-  calculate_three_way_table(k, j, i)
        tables_list[[length(tables_list) + 1]] <- new_table
        names(tables_list)[length(tables_list)] <- paste(k,"-", j, "-", i)
        
        new_g2 <-  g2(k, j, i, new_table)
        g2_list[[length(g2_list) + 1]] <- new_g2
        names(g2_list)[length(g2_list)] <- paste(k,"-", j, "-", i)
      }
    }
  }
  return(g2_list)
}



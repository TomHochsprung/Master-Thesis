warm_start_binary <- function(nodes,
                       l_total,
                       n,
                       n_hyp,
                       alpha1=alpha1,
                       alpha2=alpha2,
                       kappa = kappa,
                       maxiter = 3,
                       sCentral = "Bonferroni",
                       adjustment,
                       gFWER,
                       withWarmStarts) {
  res <- ReconstructTreeBinarySample(nodes,
                                     l_total,
                                     n,
                                     n_hyp,
                                     alpha1 = alpha1,
                                     alpha2 = alpha2,
                                     kappa = kappa,
                                     sCentral = sCentral,
                                     adjustment = adjustment,
                                     gFWER = gFWER)
  E_hat <- res$E_hat
  global_counter_hypotheses_tests <- res$global_counter_hypotheses_tests
  t_diff <- res$t_diff
  iter <- 1
 if (withWarmStarts == TRUE) { 
  while((n_hyp < global_counter_hypotheses_tests)&&(iter <=maxiter)){
    n_hyp <- ceiling(global_counter_hypotheses_tests *1.1)
    global_counter_hypotheses_tests <<- 0
    res <- ReconstructTreeBinarySample(nodes,
                                       l_total,
                                       n,
                                       n_hyp,
                                       alpha1 = alpha1,
                                       alpha2 = alpha2,
                                       kappa = kappa,
                                       sCentral = sCentral,
                                       adjustment = adjustment,
                                       gFWER = gFWER)
    E_hat <- res$E_hat
    global_counter_hypotheses_tests <- res$global_counter_hypotheses_tests
    t_diff <- t_diff + res$t_diff
    iter <- iter + 1
    print(iter)
  }
  if(iter == maxiter){
    print("Maxiter erreicht")
  }
 }
  return(list("E_hat" = E_hat, "t_diff" = t_diff, "iter" = iter))
}


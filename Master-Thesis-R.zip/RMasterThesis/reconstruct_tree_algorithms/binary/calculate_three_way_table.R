calculate_three_way_table <- function(x, y, z){
  dat_local <- get("dat", 1)
  three_way_table <- array(0, c(2, 2, 2))
  for(i in 1:2){
    for(j in 1:2){
      for(k in 1:2){
        three_way_table[i, j, k] <- nrow(dat_local[(dat_local[, x] == (i - 1)) & (dat_local[, y] == (j - 1)) & (dat_local[, z] == (k - 1)), ])
      }
    }
  }
  return(three_way_table)
}
sCentralBinarySampleBonferroni <- function(nodes,
                                     alpha,
                                     kappa,
                                     adjustment = "Bonf",
                                     gFWER = 1) {
  positives <- 0
  negatives <- 0
  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  n_type_1_errors <- 0
  n_type_2_errors <- 0
  if (adjustment == "Bonf"){
    alpha <- alpha / (length(nodes) * kappa)
  } else if (adjustment == "gBonf") {
    alpha <- alpha *gFWER / (length(nodes) * kappa)
  } else if (adjustment == "Unadjusted") {
    alpha <- alpha
  }
  quant <- qchisq(1 - alpha, df = 2)
  l <- length(nodes)
  s_hat <- numeric(l)
  for (i in 1:l) {
    nodes_sub <- setdiff(nodes, nodes[i])
    for (j in 1:kappa) {
      u_index <- as.integer(runif(1,  min = 1, max = l - 1))
      u <- nodes_sub[u_index]
      w_index <- as.integer(runif(1,  min = 1, max = l - 1)) 
      w <- nodes_sub[w_index]
      t_2 <- Sys.time()
      options("digits.secs" = 15)
      t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
      t_1 <- Sys.time()
      if (u != w){
        queries_local <- get("queries", 1)
        columns_sorted <- sort(c(u, w, nodes[i]))
        queries_local[length(queries_local) + 1] <- paste(columns_sorted[1],
                                                          "-",
                                                          columns_sorted[2],
                                                          "-",
                                                          columns_sorted[3])
        assign("queries", queries_local ,1)
        all_g2s_local <- get("all_g2s", 1)
        test_stat <- all_g2s_local[[paste(columns_sorted[1],
                                          "-",
                                          columns_sorted[2],
                                          "-",
                                          columns_sorted[3])]]
        if (test_stat > quant) {
          s_hat[i] <- s_hat[i] + 1 / kappa
        }
      } else {
        s_hat[i] <- s_hat[i] + 1 / kappa
      }
    }
  }
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- t_diff + difftime(t_2, t_1, units = "secs")
  return(list(
          "minimizers" = nodes[which(min(s_hat) == s_hat)],
          "t_diff" = t_diff
  )
         )
}


ReconstructTreeBinarySample <- function(nodes,
                                  l_total,
                                  n,
                                  n_hyp,
                                  alpha1 = 0.05,
                                  alpha2 = 0.05,
                                  kappa,
                                  sCentral = "Bonferroni",
                                  adjustment = "Bonf",
                                  gFWER = 1){
  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  l <- length(nodes)
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
  Result <- ComponentsTreeBinarySample(sort(nodes),
                                       l_total,
                                       n,
                                       n_hyp,
                                       alpha1,
                                       alpha2,
                                       kappa,
                                       sCentral = sCentral, 
                                       adjustment = adjustment,
                                       gFWER = gFWER)
  t_1 <- Sys.time()
  V <- Result$V # recall: V has also length l by construction
  E_hat <- Result$E_hat
  global_counter_hypotheses_tests <- Result$global_counter_hypotheses_tests
  t_diff <- Result$t_diff + t_diff
  for (i in 1:l) {
    sub_tree <- sort(V[[i]])
    if ((is.null(sub_tree) == FALSE) && (length(sub_tree)>1)){
      l_st <- length(sub_tree)
      indices <- numeric(l_st)
      for(j in 1:l_st){
        indices[j] <- which(nodes==sub_tree[j])
      }
      t_2 <- Sys.time()
      options("digits.secs" = 15)
      t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
      recons_res <- ReconstructTreeBinarySample(sub_tree,
                                                l_total,
                                                n,
                                                n_hyp,
                                                alpha1,
                                                alpha2,
                                                kappa,
                                                sCentral = sCentral,
                                                adjustment = adjustment,
                                                gFWER = gFWER)
      t_1 <- Sys.time()
      E_hat <- c(E_hat, recons_res$E_hat)
      global_counter_hypotheses_tests <- global_counter_hypotheses_tests + 
        recons_res$global_counter_hypotheses_tests
      t_diff <- recons_res$t_diff + t_diff
    }
  }
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
  return(list("E_hat" = E_hat,
              "global_counter_hypotheses_tests" = global_counter_hypotheses_tests,
              "t_diff" = t_diff))  
}



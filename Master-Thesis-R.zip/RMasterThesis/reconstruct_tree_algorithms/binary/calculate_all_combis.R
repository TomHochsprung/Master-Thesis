calculate_all_combis <- function(l) {
  s <- list()
  for(i in 3:l){
    for(j in 2:(i - 1)) {
      for(k in 1:(j - 1)) {
        s[[length(s) + 1]] <- c(k, j, i)
      }
    }
  }
    return(s)
}
ComponentsTreeBinarySample <- function(nodes,
                                 l_total,
                                 n,
                                 n_hyp,
                                 alpha1,
                                 alpha2,
                                 kappa,
                                 sCentral = "Bonferroni",
                                 adjustment = "Bonf",
                                 gFWER = 1) {
  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  l <- length(nodes)
  if(adjustment != "Unadjusted"){
  alpha1 <- alpha1 / l_total
  alpha2 <- alpha2 / n_hyp
  }
  # To store components V_u later
  V <- rep(list(NULL),l)
  # To store relevant edges later
  E_hat <- list()
  if (sCentral == "Bonferroni"){
   result <- sCentralBinarySampleBonferroni(
     nodes,
     alpha1,
     kappa = kappa,
     adjustment = adjustment,
     gFWER = gFWER
   ) 
  } else {
    # not implemented
    result <- sCentralBinarySampleHolm(
      nodes,
      alpha1,
      kappa = kappa)
  }
  w <- result$minimizers[1]
  N <- numeric(0)
  remaining_nodes <- setdiff(nodes, w)
  if (length(nodes) > 2) {
    all_three_way_tables_local <- get("three_way_quantities", 1)
    w1 <- remaining_nodes[as.integer(runif(1,  min = 1, max = l - 1))]
    w2 <- remaining_nodes[as.integer(runif(1,  min = 1, max = l - 2))]
    w_sorted <- sort(c(w, w1, w2))
    # query any three way table containing w
    three_way_table <- all_three_way_tables_local[[paste(w_sorted[1],
                                                         "-",
                                                         w_sorted[2],
                                                         "-",
                                                         w_sorted[3])]]
    queries_local <- get("queries", 1)
    queries_local[length(queries_local) + 1] <-paste(w_sorted[1],
                                                     "-",
                                                     w_sorted[2],
                                                     "-",
                                                     w_sorted[3])
    assign("queries", queries_local ,1)
    w_pos <- which(w == w_sorted)
    if(w_pos == 1){
      p_w <- sum(three_way_table[2, , ]) / n
    } else if (w_pos == 2) {
      p_w <- sum(three_way_table[, 2, ]) / n
    } else if (w_pos == 3) {
      p_w <- sum(three_way_table[,, 2]) / n
    }
    Sigma_w_w <- p_w * (1 - p_w)  
    cors <- numeric(l - 1)
    for(node in remaining_nodes){
      w3 <- setdiff(remaining_nodes, node)[as.integer(runif(1,  min = 1, max = l - 2))]
        w_node_sorted <- sort(c(w, node, w3))
        t_node_w <- all_three_way_tables_local[[paste(w_node_sorted[1],
                                                      "-",
                                                      w_node_sorted[2],
                                                      "-",
                                                      w_node_sorted[3])]]
        queries_local <- get("queries", 1)
        queries_local[length(queries_local) + 1] <- paste(w_node_sorted[1],
                                                          "-",
                                                          w_node_sorted[2],
                                                          "-",
                                                          w_node_sorted[3])
        assign("queries", queries_local ,1)
        w_pos <- which(w == w_node_sorted)
        node_pos <- which(node == w_node_sorted)
        if ((w_pos == 1) && (node_pos == 2)) {
          p_node_w <- sum(t_node_w[2, 2, ])
          p_node <- sum(t_node_w[, 2, ])
        } else if ((w_pos == 1) && (node_pos == 3)) {
          p_node_w <- sum(t_node_w[2, , 2])
          p_node <- sum(t_node_w[,, 2])
        } else if ((w_pos == 2) && (node_pos == 3)) {
          p_node_w <- sum(t_node_w[, 2, 2])
          p_node <- sum(t_node_w[,, 2])
        } else if ((w_pos == 2) && (node_pos == 1)) {
          p_node_w <- sum(t_node_w[2, 2, ])
          p_node <- sum(t_node_w[2, , ])
        } else if ((w_pos == 3) && (node_pos == 1)) {
          p_node_w <- sum(t_node_w[2, , 2])
          p_node <- sum(t_node_w[2, , ])
        } else if ((w_pos == 3) && (node_pos == 2)) {
          p_node_w <- sum(t_node_w[, 2, 2])
          p_node <- sum(t_node_w[, 2, ])
        }
        Sigma_node_w <- p_node_w - p_node * p_w
        Sigma_node_node <- p_node * (1 - p_node)
      cors[which(node == remaining_nodes)] <- Sigma_node_w / (Sigma_node_node * Sigma_w_w)^0.5
  }
    B <- abs(cors)
    ord <- order(B, decreasing=TRUE)
  } else {
    ord <- 1
  }
  nodes_ordered <- setdiff(nodes, w)[ord]
  global_counter_hypotheses_tests <- 0
  for(i in 1:(l-1)) {
    t <- TRUE
    l_N <- length(N)
    if(l_N > 0) {
      for(j in 1:l_N) {
        if(nodes_ordered[i] == N[j]) {
          next
        }
        global_counter_hypotheses_tests <-  global_counter_hypotheses_tests + 1
        if (nodes_ordered[i] != N[j]){
          queries_local <- get("queries", 1)
          columns_sorted <- sort(c(nodes_ordered[i], N[j], w))
          queries_local[length(queries_local) + 1] <- paste(columns_sorted[1],
                                                            "-",
                                                            columns_sorted[2],
                                                            "-",
                                                            columns_sorted[3])
          assign("queries", queries_local ,1)
          all_g2s_local <- get("all_g2s", 1)
          test_stat <- all_g2s_local[[paste(columns_sorted[1],
                                            "-",
                                            columns_sorted[2],
                                            "-",
                                            columns_sorted[3])]]
          quant <- qchisq(1 - alpha2, df = 2)
          if (test_stat > quant) {
            t <- FALSE
            V[[which(nodes == N[j])]] <- c(V[[which(nodes == N[j])]],
                                           nodes_ordered[i])
          }
      } else {
        t <- FALSE
        V[[which(nodes == N[j])]] <- c(V[[which(nodes == N[j])]],
                                       nodes_ordered[i])
      }
      }
    }
    if(t == TRUE) {
      E_hat[[length(E_hat)+1]] <- c(nodes_ordered[i],w)
      N <- c(N, nodes_ordered[i])
      V[[which(nodes == nodes_ordered[i])]] <- nodes_ordered[i]
    }
  } 
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
  return(list("V" = V,
              "E_hat" = E_hat,
              "global_counter_hypotheses_tests" = global_counter_hypotheses_tests,
              "t_diff" = t_diff))
}



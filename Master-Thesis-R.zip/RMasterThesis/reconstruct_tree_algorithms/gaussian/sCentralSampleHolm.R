sCentralSampleHolm <- function(nodes,
                               n,
                               alpha,
                               kappa) {
  positives <- 0
  negatives <- 0
  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  n_type_1_errors <- 0
  n_type_2_errors <- 0
  l <- length(nodes)
  s_hat <- numeric(l)
  for(i in 1:l) {
    nodes_sub <- setdiff(nodes, nodes[i])
    p_values <- numeric(kappa)
    true_result <- logical(kappa)
    for(j in 1:kappa) {
      u_index <- as.integer(runif(1,  min = 1, max = l - 1))
      u <- nodes_sub[u_index]
      w_index <- as.integer(runif(1,  min = 1, max = l - 1)) 
      w <- nodes_sub[w_index]
      t_2 <- Sys.time()
      options("digits.secs" = 15)
      t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
      true_result[j] <- all.equal(det(
                                Sigma[c(u, nodes[i]),
                                           c(nodes[i], w)]
                                ),0) == TRUE
      if(true_result[j] == TRUE){
        negatives <- negatives + 1
      } else {
        positives <- positives + 1
      }
      t_1 <- Sys.time()
      p_uw_v <- pcor2(c(u, w, nodes[i]), n = n)
      if(all.equal(p_uw_v, 1) != TRUE){ 
        z_uw_v <- z(p_uw_v)
        test_stat <- (n - 4)^0.5 * abs(z_uw_v)
        p_values[j] <- 1 - pnorm(test_stat)
      }

    }
    p_values_adjusted <- p.adjust(p_values, method="holm")
    for(k in 1:kappa) {
      if(p_values_adjusted[k]<= alpha){
        if(true_result[k] == TRUE){
          n_type_1_errors <- n_type_1_errors + 1
        }
        s_hat[i] <- s_hat[i] + 1 / kappa
      } else {
        if(true_result[k] == FALSE){
          n_type_2_errors <- n_type_2_errors + 1
        }
      }
    }
  }
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
  return(list(
          "minimizers" = nodes[which(min(s_hat) == s_hat)],
          "n_type_1_errors" = n_type_1_errors,
          "n_type_2_errors" = n_type_2_errors,
          "t_diff" = t_diff,
          "positives" = positives,
          "negatives" = negatives)
         )
}

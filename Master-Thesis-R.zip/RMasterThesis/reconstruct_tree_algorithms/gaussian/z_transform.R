z <- function(x){
  val <-
    1/2 * log((1 + min(x, 1-sqrt(.Machine$double.eps))) / 
                (1 - min(x, 1-sqrt(.Machine$double.eps))))
 if(is.nan(val)) {
   val <- Inf
 }
  return(val)
}
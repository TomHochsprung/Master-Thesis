pcor2 <- function(entries, n) {
  pos1 <- sort(entries[c(1,2)]) 
  pos2 <- sort(entries[c(1,3)]) 
  pos3 <- sort(entries[c(2,3)]) 
  pos4 <- entries[c(1,1)] 
  pos5 <- entries[c(2,2)] 
  pos6 <- entries[c(3,3)]
  Sigma_hat_local <- get("Sigma_hat", 1)
  query_matrix_local <- get("query_matrix", 1)
  if(approach != 1){
    query_type_local <- get("query_type", 1)
  }
  if((query_matrix_local[pos1[1], pos1[2]] == 1) || (approach == 1)){
      Sigma_1_2 <- Sigma_hat_local[pos1[1], pos1[2]]
  } else {
      calculate_cov(10, 1, 1, "Welford", path = "simulations/data_storage/data.csv")
      Sigma_1_2 <- calculate_cov(n, pos1[1], pos1[2], type = query_type_local)
      Sigma_hat_local[pos1[1], pos1[2]] <- Sigma_1_2
  }
  query_matrix_local[pos1[1],pos1[2]] <- 1
  if ((query_matrix_local[pos2[1], pos2[2]] == 1) || (approach == 1)) {
      Sigma_1_3 <- Sigma_hat_local[pos2[1], pos2[2]]
  } else {
      Sigma_1_3 <- calculate_cov(n, pos2[1], pos2[2], type = query_type_local)
      Sigma_hat_local[pos2[1], pos2[2]] <- Sigma_1_3
  }
  query_matrix_local[pos2[1],pos2[2]] <- 1
  if ((query_matrix_local[pos3[1], pos3[2]] == 1) || (approach == 1)) {
      Sigma_2_3 <- Sigma_hat_local[pos3[1], pos3[2]]
  } else {
      Sigma_2_3 <- calculate_cov(n, pos3[1], pos3[2], type = query_type_local)
      Sigma_hat_local[pos3[1], pos3[2]] <- Sigma_2_3
  }
  query_matrix_local[pos3[1],pos3[2]] <- 1
  if ((query_matrix_local[pos4[1], pos4[2]] == 1) || (approach == 1)) {
    Sigma_1_1 <- Sigma_hat_local[pos4[1], pos4[2]]
  } else {
      Sigma_1_1 <- calculate_cov(n, pos4[1], pos4[2], type = query_type_local)
      Sigma_hat_local[pos4[1], pos4[2]] <- Sigma_1_1
  }
  query_matrix_local[pos4[1],pos4[2]] <- 1
  if ((query_matrix_local[pos5[1], pos5[2]] == 1) || (approach == 1)) {
      Sigma_2_2 <- Sigma_hat_local[pos5[1], pos5[2]]
  } else {
    Sigma_2_2 <- calculate_cov(n, pos5[1], pos5[2], type = query_type_local) 
    Sigma_hat_local[pos5[1], pos5[2]] <- Sigma_2_2
  }
  query_matrix_local[pos5[1],pos5[2]] <- 1
  if ((query_matrix_local[pos6[1], pos6[2]] == 1) || (approach == 1)) {
    Sigma_3_3 <- Sigma_hat_local[pos6[1], pos6[2]]
  } else {
    Sigma_3_3 <- calculate_cov(n, pos6[1], pos6[2], type = query_type_local)
    Sigma_hat_local[pos6[1], pos6[2]] <- Sigma_3_3
  }
  query_matrix_local[pos6[1],pos6[2]] <- 1
  assign("query_matrix", query_matrix_local, 1)
  assign("Sigma_hat",Sigma_hat_local, 1)
  Cor_1_2 <- Sigma_1_2 / (Sigma_1_1 * Sigma_2_2)^0.5
  Cor_1_3 <- Sigma_1_3 / (Sigma_1_1 * Sigma_3_3)^0.5
  Cor_2_3 <- Sigma_2_3 / (Sigma_2_2 * Sigma_3_3)^0.5
  rho_uw_v <- (Cor_1_2 - Cor_1_3 * Cor_2_3) /
    ((1 - Cor_1_3^2)^0.5 * (1 - Cor_2_3^2)^0.5)
  if(is.na(rho_uw_v)) {
    rho_uw_v <- 1
  }
  return(rho_uw_v)
}
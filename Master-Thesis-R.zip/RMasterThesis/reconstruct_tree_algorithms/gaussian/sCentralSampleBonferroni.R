sCentralSampleBonferroni <- function(nodes,
                                     n,
                                     alpha,
                                     kappa,
                                     adjustment = "Bonf",
                                     gFWER = 1) {
  positives <- 0
  negatives <- 0
  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  n_type_1_errors <- 0
  n_type_2_errors <- 0
  if (adjustment == "Bonf"){
    alpha <- alpha / (length(nodes) * kappa)
  } else if (adjustment == "gBonf"){
    alpha <- alpha *gFWER / (length(nodes) * kappa)
  } else if (adjustment == "Unadjusted"){
    alpha <- alpha
  }
  quant <- qnorm(1 - alpha/2)
  l <- length(nodes)
  s_hat <- numeric(l)
  for (i in 1:l) {
    nodes_sub <- setdiff(nodes, nodes[i])
    for (j in 1:kappa) {
      u_index <- as.integer(runif(1,  min = 1, max = l - 1))
      u <- nodes_sub[u_index]
      w_index <- as.integer(runif(1,  min = 1, max = l - 1)) 
      w <- nodes_sub[w_index]
      t_2 <- Sys.time()
      options("digits.secs" = 15)
      t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
      true_result <- all.equal(det(
                                get("Sigma", 1)[c(u, nodes[i]),
                                           c(nodes[i], w)])
                               , 0) == TRUE
      if(true_result == TRUE){
        negatives <- negatives + 1
      } else {
        positives <- positives + 1
      }
      t_1 <- Sys.time()
      p_uw_v <- pcor2(c(u, w, nodes[i]), n = n)
      if ((all.equal(p_uw_v, 1) != TRUE) && (abs(p_uw_v < 1))) {
        z_uw_v <- z(p_uw_v)
        test_stat <- (n - 4)^0.5 * abs(z_uw_v)
        if (test_stat > quant) {
          s_hat[i] <- s_hat[i] + 1 / kappa
          if (true_result == TRUE) {
            n_type_1_errors <- n_type_1_errors + 1
          }
        } else {
          if(true_result == FALSE){
            n_type_2_errors <- n_type_2_errors + 1
          }
        }
      } else {
        s_hat[i] <- s_hat[i] + 1 / kappa
        if (true_result == TRUE) {
          n_type_1_errors <- n_type_1_errors + 1
        }
      }
    }
  }
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- t_diff + difftime(t_2, t_1, units = "secs")
  return(list(
          "minimizers" = nodes[which(min(s_hat) == s_hat)],
          #"query_matrix" = query_matrix,
          "n_type_1_errors" = n_type_1_errors,
          "n_type_2_errors" = n_type_2_errors,
          "t_diff" = t_diff,
          "positives" = positives,
          "negatives" = negatives)
         )
}


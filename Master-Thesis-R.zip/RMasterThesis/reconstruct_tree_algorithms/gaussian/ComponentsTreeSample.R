ComponentsTreeSample <- function(nodes,
                                 l_total,
                                 n,
                                 n_hyp,
                                 alpha1,
                                 alpha2,
                                 kappa,
                                 sCentral = "Bonferroni",
                                 adjustment = "Bonf",
                                 gFWER = 1) {


  t_1 <- Sys.time()
  t_diff <- t_1 - t_1
  if(approach != 1){
    query_type_local <- get("query_type", 1)
  }
  
  l <- length(nodes)
  if(adjustment != "Unadjusted"){
  alpha1 <- alpha1 / l_total
  alpha2 <- alpha2 / n_hyp
  }
  # To store components V_u later
  V <- rep(list(NULL),l)
  # To store relevant edges later
  E_hat <- list()
  if (sCentral == "Bonferroni"){
   result <- sCentralSampleBonferroni(
     nodes,
     n,
     alpha1,
     kappa = kappa,
     adjustment = adjustment,
     gFWER = gFWER
   ) 
  } else {
    result <- sCentralSampleHolm(
      nodes,
      n,
      alpha1,
      kappa = kappa)
  }
  w <- result$minimizers[1]
  N <- numeric(0)
  remaining_nodes <- setdiff(nodes, w)
  query_matrix_local <- get("query_matrix", pos = 1)
  Sigma_hat_local <- get("Sigma_hat", pos = 1)
  if((query_matrix_local[w, w] == 1) || (approach == 1)){
    Sigma_w_w <- Sigma_hat_local[w, w]
  } else {
    Sigma_w_w <- calculate_cov(n, w, w, type = query_type_local)
     Sigma_hat_local[w, w] <- Sigma_w_w
  }
  query_matrix_local[w, w] <- 1
  cors <- numeric(l - 1)
  for (node in remaining_nodes) {
    node_w_sorted <- sort(c(node, w))
    if ((query_matrix_local[node_w_sorted[1], node_w_sorted[2]] == 1) || (approach == 1)) {
      Sigma_node_w <- Sigma_hat_local[node_w_sorted[1], node_w_sorted[2]]
    } else {
      Sigma_node_w <- calculate_cov(n, node_w_sorted[1], node_w_sorted[2], type = query_type_local)
      Sigma_hat_local[node_w_sorted[1], node_w_sorted[2]] <- Sigma_node_w
    }
    query_matrix_local[node_w_sorted[1], node_w_sorted[2]] <- 1
    if ((query_matrix_local[node, node] == 1) || (approach == 1)) {
      Sigma_node_node <- Sigma_hat_local[node, node]
    } else {
      Sigma_node_node <- calculate_cov(n, node, node, type = query_type_local)
      Sigma_hat_local[node, node] <- Sigma_node_node
    }
    query_matrix_local[node, node] <- 1
    cors[which(node == remaining_nodes)] <- Sigma_node_w / (Sigma_node_node * Sigma_w_w)^0.5
  }
  assign("query_matrix", query_matrix_local, 1)
  assign("Sigma_hat", Sigma_hat_local, 1)
  B <- abs(cors)
  ord <- order(B, decreasing=TRUE)
  nodes_ordered <- setdiff(nodes, w)[ord]
  
  global_counter_hypotheses_tests <- 0
  for(i in 1:(l-1)) {
    t <- TRUE
    l_N <- length(N)
    if(l_N > 0) {
      for(j in 1:l_N) {
        if(nodes_ordered[i] == N[j]) {
          next
        }
        global_counter_hypotheses_tests <-  global_counter_hypotheses_tests + 1
        p_uv_w <- pcor2(c(nodes_ordered[i], N[j], w), n = n)
        if ((all.equal(p_uv_w, 1) != TRUE) && (abs(p_uv_w) < 1)) {
          z_uv_w <- z(p_uv_w) 
          test_stat <- (n - 4)^0.5 * abs(z_uv_w)
          quant <- qnorm(1 - alpha2 / 2)
          
        if (test_stat > quant) {
          t <- FALSE
          V[[which(nodes == N[j])]] <- c(V[[which(nodes == N[j])]],
                                         nodes_ordered[i])
        }
      } else {
        t <- FALSE
        V[[which(nodes == N[j])]] <- c(V[[which(nodes == N[j])]],
                                       nodes_ordered[i])
      }
      }
    }
    
    if(t == TRUE) {
      E_hat[[length(E_hat)+1]] <- c(nodes_ordered[i],w)
      N <- c(N, nodes_ordered[i])
      V[[which(nodes == nodes_ordered[i])]] <- nodes_ordered[i]
    }
    
  }
  t_2 <- Sys.time()
  options("digits.secs" = 15)
  t_diff <- difftime(t_2, t_1, units = "secs") + t_diff
  return(list("V" = V,
              "E_hat" = E_hat,
              "global_counter_hypotheses_tests" = global_counter_hypotheses_tests,
              "t_diff" = t_diff))
}


